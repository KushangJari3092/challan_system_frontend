import React from 'react'

export default function Home() {
    return (
        <>

            <h2>welcome to E-challan system</h2>
        </>
    )
}
